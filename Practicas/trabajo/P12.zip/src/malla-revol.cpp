// Nombre: Carlos, Apellidos: García Segura, DNI/pasaporte: 45901676R (DDGG IG curso 20-21)
// *********************************************************************
// **
// ** Informática Gráfica, curso 2019-20
// ** Implementación de la clase 'MallaRevol'
// **
// *********************************************************************

#include "ig-aux.h"
#include "tuplasg.h"
#include "lector-ply.h"
#include "matrices-tr.h"
#include "malla-revol.h"

using namespace std ;

// *****************************************************************************




// Método que crea las tablas de vértices, triángulos, normales y cc.de.tt.
// a partir de un perfil y el número de copias que queremos de dicho perfil.
void MallaRevol::inicializar
(
   const std::vector<Tupla3f> & perfil,     // tabla de vértices del perfil original
   const unsigned               num_copias  // número de copias del perfil
)
{
   // COMPLETAR: Práctica 2: completar: creación de la malla....
	int m = perfil.size();
	

	for (int i = 0; i< num_copias; i++)
		for (int j = 0; j < perfil.size(); j++)
		{
			double angulo = (2 * M_PI * i) / (num_copias - 1);
			float x = perfil[j](2) * cos(angulo) + perfil[j](0)*sin(angulo);
			float y = perfil[j](1);
			float z = perfil[j](0) * cos(angulo) - perfil[j](2)*sin(angulo); 
			
				vertices.push_back({ x, y ,z });
		}
	

	for (int i = 0; i< num_copias-1; i++)
		for (int j = 0; j < m-1; j++)
		{
			int k = i * m + j;
			triangulos.push_back({ k, k + m, k + m + 1 });
			triangulos.push_back({ k, k + m + 1, k + 1 });
		}
	

}

// -----------------------------------------------------------------------------
// constructor, a partir de un archivo PLY

MallaRevolPLY::MallaRevolPLY
(
	const std::string& nombre_arch,
	const unsigned      nperfiles
)
{
   ponerNombre( std::string("malla por revolución del perfil en '"+ nombre_arch + "'" ));
   // COMPLETAR: práctica 2: crear la malla de revolución
   // Leer los vértice del perfil desde un PLY, después llamar a 'inicializar'
   // ...........................
   std::vector<Tupla3f> perfil;
   LeerVerticesPLY(nombre_arch, perfil);
   inicializar(perfil, nperfiles);

}

Cilindro::Cilindro(const int num_verts_per, const unsigned nperfiles) : MallaRevol() {
	std::vector<Tupla3f> perfil;
		Tupla3f vertice;
		float radio = 1;
		float altura = 1;

		for (int i = 0; i < num_verts_per; i++)
		{
			vertice(0) = radio;
			vertice(1) = (altura / num_verts_per) * i;
			vertice(2) = 0;
			perfil.push_back(vertice);
		}
	
	inicializar(perfil, nperfiles);
}

Cono::Cono(const int num_verts_per, const unsigned nperfiles) : MallaRevol() {
	std::vector<Tupla3f> perfil;
	Tupla3f vertice;
	float radio = 1;
	float altura = 1;
	for (int i = 0; i <= num_verts_per; i++)
		{
			vertice(0) = (radio / num_verts_per) * i;
			vertice(1) = altura-(altura / num_verts_per) * i;
			vertice(2) = 0;
			perfil.push_back(vertice);
		}

	inicializar(perfil, nperfiles);
}


Esfera::Esfera(const int num_verts_per, const unsigned nperfiles) : MallaRevol() {
	std::vector<Tupla3f> perfil;
	Tupla3f vertice, punto_inicial;
	float radio = 1;
	punto_inicial = { 0.0, radio, 0.0 };
	for (int i = 0; i <= num_verts_per; i++) {
		float angulo = ((M_PI * i) / (num_verts_per));
		vertice(0) = punto_inicial(0) * cos(angulo) + punto_inicial(1) * sin(angulo);
		vertice(1) = punto_inicial(1) * cos(angulo) - punto_inicial(0) * sin(angulo);
		vertice(2) = punto_inicial(2);
		
		perfil.push_back(vertice);
	}

	inicializar(perfil, nperfiles);
}


SemiEsfera::SemiEsfera(const int num_verts_per, const unsigned nperfiles) : MallaRevol() {
	std::vector<Tupla3f> perfil;
	Tupla3f vertice, punto_inicial;
	float radio = 1;
	punto_inicial = { 0.0, radio, 0.0 };
	for (int i = 0; i <= num_verts_per/2; i++) {
		float angulo = ((M_PI * i) / (num_verts_per));
		vertice(0) = punto_inicial(0) * cos(angulo) + punto_inicial(1) * sin(angulo);
		vertice(1) = punto_inicial(1) * cos(angulo) - punto_inicial(0) * sin(angulo);
		vertice(2) = punto_inicial(2);

		perfil.push_back(vertice);
	}

	inicializar(perfil, nperfiles);
}